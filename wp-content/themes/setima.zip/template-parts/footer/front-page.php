<script type="text/javascript">var $ = window.jQuery;</script><script src="https://min30327.github.io/luxy.js/dist/js/luxy.js"></script>
<script charset="utf-8">
var isMobile = /iPhone|iPad|Android/i.test(navigator.userAgent);
if (!isMobile) {
luxy.init({
wrapper: '#luxy',
wrapperSpeed: 0.065,
});
}
</script>
<script>
// Stop body scroll when mobile menu is open
const body = document.body;
function letBodyScroll(bool) {
if (bool) {
body.style.overflow = 'hidden';
} else {
body.style.overflow = 'auto';
}
}
const targetNode = document.querySelector('.navbar_menu-button');
const config = { attributes: true, childList: false, subtree: false };
const callback = function (mutationsList, observer) {
for (let i = 0; i < mutationsList.length; i++) {
if (mutationsList[i].type === 'attributes') {
const menuIsOpen = mutationsList[i].target.classList.contains('w--open');
letBodyScroll(menuIsOpen);
}
}
};
const observer = new MutationObserver(callback);
observer.observe(targetNode, config);
</script><script type="module">import*as UdeslyBanner from"https://cdn.jsdelivr.net/npm/udesly-ad-banner@0.0.4/loader/index.js";UdeslyBanner.defineCustomElements(),document.body.append(document.createElement("udesly-banner"));</script>