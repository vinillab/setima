
  <div class="utility-page_component">
    <div class="utility-page_wrapper w-password-page w-form">
      <form action="<?php echo add_query_arg('action','postpass',wp_login_url()) ?>" method="post" id="email-form" name="email-form" data-name="Email Form" class="utility-page_form w-password-page" data-wf-page-id="657c4a92c364e232beb357e1" data-wf-element-id="60d3fa3a5a19c1169cd58c4100000000000c"><img width="106" src="https://d3e54v103j8qbb.cloudfront.net/static/utility-lock.ae54711958.svg" alt="" class="utility-page_image">
        <h3>Protected Page</h3><input type="password" class="form_input w-password-page w-input" autofocus="true" maxlength="256" name="post_password" data-name="field" placeholder="Enter your password" id="pass"><input type="submit" value="Submit" data-wait="Please wait..." class="button w-password-page w-button">
        <div class="form_message-error w-password-page w-form-fail">
          <div>Incorrect password. Please try again.</div>
        </div>
        
        
      </form>
    </div>
  </div>
  
  