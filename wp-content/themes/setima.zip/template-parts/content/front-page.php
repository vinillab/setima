
  <div id="luxy" class="page-wrapper">
    <div class="global-styles w-embed" sym="true">
      <style>
/* Make text look crisper and more legible in all browsers */
body {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
}
/* Focus state style for keyboard navigation for the focusable elements */
*[tabindex]:focus-visible,
  input[type="file"]:focus-visible {
   outline: 0.125rem solid #4d65ff;
   outline-offset: 0.125rem;
}
/* Get rid of top margin on first element in any rich text element */
.w-richtext > :not(div):first-child, .w-richtext > div:first-child > :first-child {
  margin-top: 0 !important;
}
/* Get rid of bottom margin on last element in any rich text element */
.w-richtext>:last-child, .w-richtext ol li:last-child, .w-richtext ul li:last-child {
	margin-bottom: 0 !important;
}
/* Prevent all click and hover interaction with an element */
.pointer-events-off {
	pointer-events: none;
}
/* Enables all click and hover interaction with an element */
.pointer-events-on {
  pointer-events: auto;
}
/* Create a class of .div-square which maintains a 1:1 dimension of a div */
.div-square::after {
	content: "";
	display: block;
	padding-bottom: 100%;
}
/* Make sure containers never lose their center alignment */
.container-medium,.container-small, .container-large {
	margin-right: auto !important;
  margin-left: auto !important;
}
/* 
Make the following elements inherit typography styles from the parent and not have hardcoded values. 
Important: You will not be able to style for example "All Links" in Designer with this CSS applied.
Uncomment this CSS to use it in the project. Leave this message for future hand-off.
*/
/*
a,
.w-input,
.w-select,
.w-tab-link,
.w-nav-link,
.w-dropdown-btn,
.w-dropdown-toggle,
.w-dropdown-link {
  color: inherit;
  text-decoration: inherit;
  font-size: inherit;
}
*/
/* Apply "..." after 3 lines of text */
.text-style-3lines {
	display: -webkit-box;
	overflow: hidden;
	-webkit-line-clamp: 3;
	-webkit-box-orient: vertical;
}
/* Apply "..." after 2 lines of text */
.text-style-2lines {
	display: -webkit-box;
	overflow: hidden;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
}
/* Adds inline flex display */
.display-inlineflex {
  display: inline-flex;
}
/* These classes are never overwritten */
.hide {
  display: none !important;
}
@media screen and (max-width: 991px) {
    .hide, .hide-tablet {
        display: none !important;
    }
}
  @media screen and (max-width: 767px) {
    .hide-mobile-landscape{
      display: none !important;
    }
}
  @media screen and (max-width: 479px) {
    .hide-mobile{
      display: none !important;
    }
}
.margin-0 {
  margin: 0rem !important;
}
.padding-0 {
  padding: 0rem !important;
}
.spacing-clean {
padding: 0rem !important;
margin: 0rem !important;
}
.margin-top {
  margin-right: 0rem !important;
  margin-bottom: 0rem !important;
  margin-left: 0rem !important;
}
.padding-top {
  padding-right: 0rem !important;
  padding-bottom: 0rem !important;
  padding-left: 0rem !important;
}
.margin-right {
  margin-top: 0rem !important;
  margin-bottom: 0rem !important;
  margin-left: 0rem !important;
}
.padding-right {
  padding-top: 0rem !important;
  padding-bottom: 0rem !important;
  padding-left: 0rem !important;
}
.margin-bottom {
  margin-top: 0rem !important;
  margin-right: 0rem !important;
  margin-left: 0rem !important;
}
.padding-bottom {
  padding-top: 0rem !important;
  padding-right: 0rem !important;
  padding-left: 0rem !important;
}
.margin-left {
  margin-top: 0rem !important;
  margin-right: 0rem !important;
  margin-bottom: 0rem !important;
}
.padding-left {
  padding-top: 0rem !important;
  padding-right: 0rem !important;
  padding-bottom: 0rem !important;
}
.margin-horizontal {
  margin-top: 0rem !important;
  margin-bottom: 0rem !important;
}
.padding-horizontal {
  padding-top: 0rem !important;
  padding-bottom: 0rem !important;
}
.margin-vertical {
  margin-right: 0rem !important;
  margin-left: 0rem !important;
}
.padding-vertical {
  padding-right: 0rem !important;
  padding-left: 0rem !important;
}
.w-slider-dot {
  background-color: transparent;
  border: 1px solid #FFF;
  width: 10px;
  height: 10px;
}
.w-slider-dot.w-active {
  background-color: #FFF;
  width: 10px;
  height: 10px;
}
</style>
    </div>
    <div data-animation="default" class="navbar_component w-nav" data-easing2="ease" fs-scrolldisable-element="smart-nav" data-easing="ease" data-collapse="medium" data-w-id="6fa26e57-5253-d85a-8c31-72996cb95602" role="banner" data-duration="400">
      <div class="navbar_container">
        <a href="#" class="navbar1_logo-link w-nav-brand"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-setima.svg?v=1702910687" loading="lazy" alt="" class="navbar1_logo"></a>
        <nav role="navigation" class="navbar1_menu is-page-height-tablet w-nav-menu">
          <a href="#sobre" class="navbar1_link w-nav-link">SOBRE</a>
          <a href="#por-que" class="navbar1_link w-nav-link">POR QUÊ?</a>
          <a href="#como-pensamos" class="navbar1_link w-nav-link">COMO PENSAMOS</a>
          <a href="#entregaveis" class="navbar1_link w-nav-link">ENTREGÁVEIS</a>
          <a href="#holding" class="navbar1_link w-nav-link">HOLDING</a>
          <a href="#contato" class="navbar1_link w-nav-link">CONTATO</a>
        </nav>
        <div class="navbar1_menu-button w-nav-button">
          <div class="menu-icon1">
            <div class="menu-icon1_line-top"></div>
            <div class="menu-icon1_line-middle">
              <div class="menu-icon_line-middle-inner"></div>
            </div>
            <div class="menu-icon1_line-bottom"></div>
          </div>
        </div>
      </div>
    </div>
    <main class="main-wrapper">
      <header class="section_hero">
        <div class="padding-global">
          <div class="container-large">
            <div class="hero_content"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/path-setima-hero.svg?v=1702910687" loading="lazy" alt="" class="path-setima">
              <p class="text-size-large">× TRANSFORMAR NEGÓCIOS<br>× CONSTRUIR MARCAS<br>× CRIAR CONTEÚDO<br>× DESENHAR EXPERIÊNCIAS</p>
            </div>
          </div>
        </div>
        <div class="header7_background-video-wrapper">
          <div data-poster-url="<?php echo get_template_directory_uri(); ?>/assets/videos/eae05137-8763-48c0-838e-09ea0af20c6a-poster-00001.jpg?v=1702910687" data-video-urls="<?php echo get_template_directory_uri(); ?>/assets/videos/eae05137-8763-48c0-838e-09ea0af20c6a-transcode.mp4?v=1702910687 undefined, <?php echo get_template_directory_uri(); ?>/assets/videos/eae05137-8763-48c0-838e-09ea0af20c6a-transcode.webm?v=1702910687 undefined" data-autoplay="true" data-loop="true" data-wf-ignore="true" data-beta-bgvideo-upgrade="false" class="header7_background-video w-background-video w-background-video-atom"><video id="c58a3e4a-5c77-dcc1-90a7-896ae22b9466-video" autoplay="" loop="" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/videos/eae05137-8763-48c0-838e-09ea0af20c6a-poster-00001.jpg?v=1702910687'); " muted="" playsinline="" data-wf-ignore="true" data-object-fit="cover">
              <source src="<?php echo get_template_directory_uri(); ?>/assets/videos/eae05137-8763-48c0-838e-09ea0af20c6a-transcode.mp4?v=1702910687" data-wf-ignore="true">
              <source src="<?php echo get_template_directory_uri(); ?>/assets/videos/eae05137-8763-48c0-838e-09ea0af20c6a-transcode.webm?v=1702910687" data-wf-ignore="true">
            </video></div>
          <div class="video-overlay-layer hide"></div>
        </div>
      </header>
      <header id="sobre" class="section_sobre">
        <div class="padding-global">
          <div class="container-large">
            <div class="padding-section-sobre">
              <h2 class="heading-style-h2">CONSULTING <strong>×</strong> AGENCY <strong>×</strong> PRODUCTION</h2>
              <div class="max-width-large">
                <div class="spacer-small"></div>
                <p class="text-size-medium">Nossa profunda expertise, combinada com metodologias<br>avançadas e uma estrutura completa e otimizada, resulta em<br>uma capacidade de entrega tão ampla quanto a vantagem<br>competitiva que somos capazes de oferecer.</p>
              </div>
            </div>
          </div>
        </div>
      </header>
      <header class="section_sobre-intro">
        <div class="padding-global">
          <div class="container-large">
            <div class="padding-section-large">
              <div class="text-align-center">
                <p class="text_como-pensamos">SOMOS UMA EMPRESA INDEPENDENTE ATUANDO A PARTIR DO ENCONTRO ENTRE A CONSULTORIA, A COMUNICAÇÃO E A PRODUÇÃO.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="header65_background-image-wrapper"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/group-25.png?v=1702910687" loading="eager" sizes="100vw" srcset="<?php echo get_template_directory_uri(); ?>/assets/images/group-25-p-500.png?v=1702910687 500w, <?php echo get_template_directory_uri(); ?>/assets/images/group-25-p-800.png?v=1702910687 800w, <?php echo get_template_directory_uri(); ?>/assets/images/group-25-p-1080.png?v=1702910687 1080w, <?php echo get_template_directory_uri(); ?>/assets/images/group-25-p-1600.png?v=1702910687 1600w, <?php echo get_template_directory_uri(); ?>/assets/images/group-25.png?v=1702910687 1920w" alt="" class="header65_background-image"></div>
      </header>
      <header class="section_video">
        <div class="header11_component">
          <div class="custom-video-wrapper">
            <div class="video-vimeo-wrapper">
              <div style="-webkit-transform:translate3d(0, 0, 0) scale3d(1.2, 1.2, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, 0, 0) scale3d(1.2, 1.2, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, 0, 0) scale3d(1.2, 1.2, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, 0, 0) scale3d(1.2, 1.2, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0)" class="vimeo-embed w-embed w-iframe"><iframe id="vimeo-video" src="https://player.vimeo.com/video/749973252?background=1" width="100%" height="100%" frameborder="0" allow="autoplay; fullscreen" allowfullscreen=""></iframe></div>
              <div style="opacity:1" class="vimdeo-player-overlay"></div>
            </div>
            <div vimeo="unmute" data-w-id="38d91136-3f93-ceed-76d4-1d9bef03e9d4" style="opacity:1;-webkit-transform:translate3d(0, 0em, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, 0em, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, 0em, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, 0em, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0)" class="video-unmute-button">
              <div class="is-magnetic">
                <div class="video-unmute-wrapper">
                  <a href="#" class="play-link">PLAY</a>
                </div>
              </div>
            </div>
            <div style="display:none;-webkit-transform:translate3d(0, 1.5em, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, 1.5em, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, 1.5em, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, 1.5em, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);opacity:0" class="video-play-pause-toggle">
              <div class="is-magnetic">
                <div class="video-play-pause-wrapper">
                  <div vimeo="play" data-w-id="38d91136-3f93-ceed-76d4-1d9bef03e9db" style="display:none;opacity:0;-webkit-transform:translate3d(0, 0, 0) scale3d(0.5, 0.5, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, 0, 0) scale3d(0.5, 0.5, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, 0, 0) scale3d(0.5, 0.5, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, 0, 0) scale3d(0.5, 0.5, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0)" class="video-play-wrapper">
                    <div class="play-pause--icon w-embed"><svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-play">
                        <polygon points="5 3 19 12 5 21 5 3"></polygon>
                      </svg></div>
                  </div>
                  <div vimeo="pause" data-w-id="38d91136-3f93-ceed-76d4-1d9bef03e9dd" style="display:flex;opacity:1;-webkit-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0)" class="video-pause-wrapper">
                    <div class="play-pause--icon w-embed"><svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-pause">
                        <rect x="6" y="4" width="4" height="16"></rect>
                        <rect x="14" y="4" width="4" height="16"></rect>
                      </svg></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
      <section id="por-que" class="section_por_que background-color-black">
        <div class="padding-global">
          <div class="container-large">
            <div class="padding-section-large">
              <div class="max-width-large">
                <h2 class="heading-style-h2">POR QUE NOS ESCOLHER?</h2>
              </div>
              <div class="spacer-xxlarge"></div>
              <div class="perguntas_component max-width-large align-center">
                <div class="pergunta_item">
                  <div data-w-id="43b1d2d7-88bd-fc63-6082-63b71eb98b82" class="accordion2_top">
                    <div class="perguntas_pergunta">Estrutura é in-house</div>
                    <div class="accordion2_icon w-embed"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="57.688" height="57.688" viewBox="0 0 57.688 57.688">
                        <defs>
                          <linearGradient id="linear-gradient" x1="0.146" y1="0.854" x2="0.854" y2="0.146" gradientUnits="objectBoundingBox">
                            <stop offset="0" stop-color="#1d37bf"></stop>
                            <stop offset="1" stop-color="#672c99"></stop>
                          </linearGradient>
                        </defs>
                        <g id="Group_34" data-name="Group 34" transform="translate(-1361.695 -3425.565)">
                          <circle id="Ellipse_3" data-name="Ellipse 3" cx="28.844" cy="28.844" r="28.844" transform="translate(1361.695 3425.565)" fill="url(#linear-gradient)"></circle>
                          <g id="Group_33" data-name="Group 33">
                            <path id="Path_32" data-name="Path 32" d="M1403.123,3458.24h-8.754v8.754h-7.66v-8.754h-8.755v-7.662h8.755v-8.753h7.66v8.753h8.754Z" fill="#fff"></path>
                          </g>
                        </g>
                      </svg></div>
                  </div>
                  <div style="height:0px" class="accordion2_bottom">
                    <p class="perguntas_content">Com talentos brilhantes em casa, e outros plugados conforme a necessidade, nossas entregas vão de ponta a ponta e possibilitam uma enorme vantagem competitiva.</p>
                    <div class="spacer-medium"></div>
                  </div>
                </div>
                <div class="pergunta_item">
                  <div data-w-id="0a355151-a3ea-889e-9bb1-d4e65ae23491" class="accordion2_top">
                    <div class="perguntas_pergunta">Atuação ampla</div>
                    <div class="accordion2_icon w-embed"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="57.688" height="57.688" viewBox="0 0 57.688 57.688">
                        <defs>
                          <linearGradient id="linear-gradient" x1="0.146" y1="0.854" x2="0.854" y2="0.146" gradientUnits="objectBoundingBox">
                            <stop offset="0" stop-color="#1d37bf"></stop>
                            <stop offset="1" stop-color="#672c99"></stop>
                          </linearGradient>
                        </defs>
                        <g id="Group_34" data-name="Group 34" transform="translate(-1361.695 -3425.565)">
                          <circle id="Ellipse_3" data-name="Ellipse 3" cx="28.844" cy="28.844" r="28.844" transform="translate(1361.695 3425.565)" fill="url(#linear-gradient)"></circle>
                          <g id="Group_33" data-name="Group 33">
                            <path id="Path_32" data-name="Path 32" d="M1403.123,3458.24h-8.754v8.754h-7.66v-8.754h-8.755v-7.662h8.755v-8.753h7.66v8.753h8.754Z" fill="#fff"></path>
                          </g>
                        </g>
                      </svg></div>
                  </div>
                  <div style="height:0px" class="accordion2_bottom">
                    <p class="perguntas_content">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
                    <div class="spacer-medium"></div>
                  </div>
                </div>
                <div class="pergunta_item">
                  <div data-w-id="91b76213-420f-0395-9683-bde809fc271c" class="accordion2_top">
                    <div class="perguntas_pergunta">Independência</div>
                    <div class="accordion2_icon w-embed"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="57.688" height="57.688" viewBox="0 0 57.688 57.688">
                        <defs>
                          <linearGradient id="linear-gradient" x1="0.146" y1="0.854" x2="0.854" y2="0.146" gradientUnits="objectBoundingBox">
                            <stop offset="0" stop-color="#1d37bf"></stop>
                            <stop offset="1" stop-color="#672c99"></stop>
                          </linearGradient>
                        </defs>
                        <g id="Group_34" data-name="Group 34" transform="translate(-1361.695 -3425.565)">
                          <circle id="Ellipse_3" data-name="Ellipse 3" cx="28.844" cy="28.844" r="28.844" transform="translate(1361.695 3425.565)" fill="url(#linear-gradient)"></circle>
                          <g id="Group_33" data-name="Group 33">
                            <path id="Path_32" data-name="Path 32" d="M1403.123,3458.24h-8.754v8.754h-7.66v-8.754h-8.755v-7.662h8.755v-8.753h7.66v8.753h8.754Z" fill="#fff"></path>
                          </g>
                        </g>
                      </svg></div>
                  </div>
                  <div style="height:0px" class="accordion2_bottom">
                    <p class="perguntas_content">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
                    <div class="spacer-medium"></div>
                  </div>
                </div>
                <div class="pergunta_item">
                  <div data-w-id="f7677562-641f-a7bf-7be9-291f49b916f0" class="accordion2_top">
                    <div class="perguntas_pergunta">Respeito pela verba</div>
                    <div class="accordion2_icon w-embed"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="57.688" height="57.688" viewBox="0 0 57.688 57.688">
                        <defs>
                          <linearGradient id="linear-gradient" x1="0.146" y1="0.854" x2="0.854" y2="0.146" gradientUnits="objectBoundingBox">
                            <stop offset="0" stop-color="#1d37bf"></stop>
                            <stop offset="1" stop-color="#672c99"></stop>
                          </linearGradient>
                        </defs>
                        <g id="Group_34" data-name="Group 34" transform="translate(-1361.695 -3425.565)">
                          <circle id="Ellipse_3" data-name="Ellipse 3" cx="28.844" cy="28.844" r="28.844" transform="translate(1361.695 3425.565)" fill="url(#linear-gradient)"></circle>
                          <g id="Group_33" data-name="Group 33">
                            <path id="Path_32" data-name="Path 32" d="M1403.123,3458.24h-8.754v8.754h-7.66v-8.754h-8.755v-7.662h8.755v-8.753h7.66v8.753h8.754Z" fill="#fff"></path>
                          </g>
                        </g>
                      </svg></div>
                  </div>
                  <div style="height:0px" class="accordion2_bottom">
                    <p class="perguntas_content">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
                    <div class="spacer-medium"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="section_clientes">
        <div class="padding-global">
          <div class="container-large">
            <div class="padding-section-large">
              <div class="max-width-large">
                <h2 class="heading-style-h2">NOSSOS&nbsp;CLIENTES</h2>
              </div>
              <div class="spacer-xlarge"></div>
              <div class="clientes_component"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-vw-caminhoes.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-brasilprev.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-westrock.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-ey.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-intermarine.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-intercarta.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-bobs.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-petrobras.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-ricardo_almeida.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-vw.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-iba.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-loggi.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-embraer.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-valfilm.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-toyota.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-nortel.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-adeste.png?v=1702910687" loading="lazy" alt="" class="cliente_logo"></div>
            </div>
          </div>
        </div>
      </section>
      <header id="como-pensamos" class="section_como-pensamos">
        <div class="padding-global">
          <div class="container-large">
            <div class="paddibg-section_como-pensamos">
              <h2 class="heading-style-h2">COMO A GENTE PENSA</h2>
              <div class="spacer-slider"></div>
              <div class="container-slider">
                <div data-delay="4000" data-animation="cross" class="slider w-slider" data-autoplay="false" data-easing="ease" data-hide-arrows="false" data-disable-swipe="false" data-autoplay-limit="0" data-nav-spacing="3" data-duration="500" data-infinite="true">
                  <div class="slider-mask w-slider-mask">
                    <div class="slider-item w-slide">
                      <div class="slider_content">
                        <div class="padding-slider">
                          <div class="text-align-center">
                            <p class="slider_content-text">Bons argumentos são sempre bons argumentos, não importa de que lado da mesa venham.</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="slider-item w-slide">
                      <div class="slider_content">
                        <div class="padding-slider">
                          <div class="text-align-center">
                            <p class="slider_content-text">Bons argumentos são sempre bons argumentos, não importa de que lado da mesa venham.</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="slider-item w-slide">
                      <div class="slider_content">
                        <div class="padding-slider">
                          <div class="text-align-center">
                            <p class="slider_content-text">Bons argumentos são sempre bons argumentos, não importa de que lado da mesa venham.</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="slider-item w-slide">
                      <div class="slider_content">
                        <div class="padding-slider">
                          <div class="text-align-center">
                            <p class="slider_content-text">Bons argumentos são sempre bons argumentos, não importa de que lado da mesa venham.</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="slider-item w-slide">
                      <div class="slider_content">
                        <div class="padding-slider">
                          <div class="text-align-center">
                            <p class="slider_content-text">Bons argumentos são sempre bons argumentos, não importa de que lado da mesa venham.</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="hide w-slider-arrow-left">
                    <div class="w-icon-slider-left"></div>
                  </div>
                  <div class="hide w-slider-arrow-right">
                    <div class="w-icon-slider-right"></div>
                  </div>
                  <div class="slider-nav w-slider-nav w-round"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="header30_background-image-wrapper">
          <div class="image-overlay-layer"></div><img src="<?php echo get_template_directory_uri(); ?>/assets/images/group-41.png?v=1702910687" loading="eager" sizes="100vw" srcset="<?php echo get_template_directory_uri(); ?>/assets/images/group-41-p-500.png?v=1702910687 500w, <?php echo get_template_directory_uri(); ?>/assets/images/group-41-p-800.png?v=1702910687 800w, <?php echo get_template_directory_uri(); ?>/assets/images/group-41-p-1080.png?v=1702910687 1080w, <?php echo get_template_directory_uri(); ?>/assets/images/group-41-p-1600.png?v=1702910687 1600w, <?php echo get_template_directory_uri(); ?>/assets/images/group-41.png?v=1702910687 1920w" alt="" class="header30_background-image">
        </div>
      </header>
      <header id="entregaveis" class="section_entregaveis">
        <div class="padding-global">
          <div class="container-large">
            <div class="padding-section-entregaveis">
              <div class="max-width-large">
                <h2 class="heading-style-h2">NOSSOS ENTREGÁVEIS A PARTIR DE ESTRATÉGIA, DO DESIGN E DO CONTEÚDO</h2>
              </div>
              <div class="spacer-xxlarge"></div>
              <div class="infografico_component">
                <div class="infografico_image-wrapper"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/image-infografico.png?v=1702910687" loading="eager" srcset="<?php echo get_template_directory_uri(); ?>/assets/images/image-infografico-p-500.png?v=1702910687 500w, <?php echo get_template_directory_uri(); ?>/assets/images/image-infografico.png?v=1702910687 545w" alt="" sizes="(max-width: 479px) 92vw, (max-width: 767px) 93vw, 540px" class="infografico_image">
                  <div><img src="<?php echo get_template_directory_uri(); ?>/assets/images/path1.png?v=1702910687" loading="lazy" alt="" class="infografico-path1">
                    <p class="infografico-text1">FILM AND PHOTOGRAPHY<br>MOTION AND DESIGN<br>BRANDED CONTENT<br>LIVE STREAMING<br>CRAFT EXPERIENCES</p>
                  </div>
                  <div><img src="<?php echo get_template_directory_uri(); ?>/assets/images/path3.png?v=1702910687" loading="lazy" alt="" class="infografico-path2">
                    <p class="infografico-text12">FILM AND PHOTOGRAPHY<br>MOTION AND DESIGN<br>BRANDED CONTENT<br>LIVE STREAMING<br>CRAFT EXPERIENCES</p>
                  </div>
                  <div><img src="<?php echo get_template_directory_uri(); ?>/assets/images/path2.png?v=1702910687" loading="lazy" alt="" class="infografico-path3">
                    <p class="infografico-text3">EXPERIENCE DESIGN<br>UX AND CX DESIGN<br>DIGITAL AND GRAPHIC DESIGN<br>EDITORIAL DESIGN<br>RETAIL DESIGN<br>PACKAGING</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
      <section id="holding" class="section_holding">
        <div class="padding-global">
          <div class="container-large">
            <div class="padding-section-large">
              <div class="max-width-full text-align-center">
                <h2 class="heading-style-h2">SOMOS PARTE DE UMA HOLDING<br>E ISSO FAZ TODA A DIFERENÇA</h2>
                <div class="spacer-large"></div>
                <div class="logos_component"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-setima_vertical.png?v=1702910687" loading="lazy" alt="" class="holding_logos"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-555studios.png?v=1702910687" loading="lazy" alt="" class="holding_logos"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-fset.png?v=1702910687" loading="lazy" alt="" class="holding_logos"></div>
              </div>
              <div class="max-width-large align-center">
                <section class="tab_component">
                  <div class="padding-section-large">
                    <div data-current="Tab 1" data-easing="ease" data-duration-in="300" data-duration-out="100" class="holding_component w-tabs">
                      <div class="holding_tabs-menu no-scrollbar w-tab-menu">
                        <a data-w-tab="Tab 1" class="holding_tab-link w-inline-block w-tab-link w--current">
                          <div>555 Studios</div>
                        </a>
                        <a data-w-tab="Tab 2" class="holding_tab-link w-inline-block w-tab-link">
                          <div>F.Set</div>
                        </a>
                      </div>
                      <div class="holding_tabs-content w-tab-content">
                        <div data-w-tab="Tab 1" class="holdings_tab-pane w-tab-pane w--tab-active">
                          <div class="rich-text-holding w-richtext">
                            <h3 class="heading">Produção Virtual de nível internacional agora no Brasil.</h3>
                            <p class="paragraph-2">O 555 é o ambiente de produção virtual (VP) perfeito, fornecendo uma solução para criadores de conteúdo em projetos de todos os tamanhos e orçamentos.<br>A partir da combinação de painéis de LED, game engines de última geração, sistemas de tracking, ambientes virtuais e cenários práticos, criamos um ambiente versátil e imersivo onde a fusão do mundo físico e virtual possibilita a configuração de set’s nos quais atores, apresentadores, diretores de fotografia e toda a equipe de produção possam ver e interagir com o conteúdo que os envolve de maneira natural.<br>Da fusão do real com a realidade aumentada ao uso de meta- humanos e holografias, as oportunidades de criarmos storytellings cada vez mais surpreendentes estão avançando dia após dia.</p>
                            <p>
                              <a href="#" class="button-richtext">SAIBA MAIS</a>
                            </p>
                          </div>
                        </div>
                        <div data-w-tab="Tab 2" class="holdings_tab-pane w-tab-pane">
                          <div class="rich-text-holding w-richtext">
                            <h3>Produção Virtual de nível internacional agora no Brasil.</h3>
                            <p>O 555 é o ambiente de produção virtual (VP) perfeito, fornecendo uma solução para criadores de conteúdo em projetos de todos os tamanhos e orçamentos.<br>A partir da combinação de painéis de LED, game engines de última geração, sistemas de tracking, ambientes virtuais e cenários práticos, criamos um ambiente versátil e imersivo onde a fusão do mundo físico e virtual possibilita a configuração de set’s nos quais atores, apresentadores, diretores de fotografia e toda a equipe de produção possam ver e interagir com o conteúdo que os envolve de maneira natural.<br>Da fusão do real com a realidade aumentada ao uso de meta- humanos e holografias, as oportunidades de criarmos storytellings cada vez mais surpreendentes estão avançando dia após dia.</p>
                            <p>
                              <a href="#" class="button-richtext">SAIBA MAIS</a>
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </div>
      </section>
      <footer id="contato" class="footer4_component">
        <div class="padding-global">
          <div class="container-large">
            <div class="padding-footer">
              <div class="w-layout-grid footer4_top-wrapper">
                <a href="#" id="w-node-_70fd9a2e-e60f-53fb-b421-20242f157ccd-beb357e0" class="footer4_logo-link w-nav-brand"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-setima_preto.png?v=1702910687" loading="lazy" alt=""></a>
                <div class="footer3_details-wrapper">
                  <div class="text-size-medium">CHAMA A GENTE</div>
                  <div class="spacer-medium"></div>
                  <div class="text-size-small">ENDEREÇO</div>
                  <div class="text-size-regular">R. VAPABUSSU, 308, SÃO PAULO, SP</div>
                  <div class="spacer-small"></div>
                  <div class="text-size-small">PHONE</div>
                  <div class="text-size-regular">
                    <a href="#">+55 11 5034 4821<br></a>
                  </div>
                  <div class="spacer-small"></div>
                  <div class="text-size-small text-weight-semibold">EMAIL</div>
                  <div class="text-size-regular">
                    <a href="#">SETIMA@SETIMA.CC</a>
                  </div>
                </div>
                <div id="w-node-_70fd9a2e-e60f-53fb-b421-20242f157cda-beb357e0" class="w-layout-grid footer4_social-list">
                  <div class="text-size-medium">SIGA</div>
                  <div class="spacer-medium"></div>
                  <div class="footer_icons-wrapper">
                    <a href="#" class="footer4_social-link w-inline-block">
                      <div class="icon-embed-xsmall w-embed"><svg width="100%" height="100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path fill-rule="evenodd" clip-rule="evenodd" d="M16 3H8C5.23858 3 3 5.23858 3 8V16C3 18.7614 5.23858 21 8 21H16C18.7614 21 21 18.7614 21 16V8C21 5.23858 18.7614 3 16 3ZM19.25 16C19.2445 17.7926 17.7926 19.2445 16 19.25H8C6.20735 19.2445 4.75549 17.7926 4.75 16V8C4.75549 6.20735 6.20735 4.75549 8 4.75H16C17.7926 4.75549 19.2445 6.20735 19.25 8V16ZM16.75 8.25C17.3023 8.25 17.75 7.80228 17.75 7.25C17.75 6.69772 17.3023 6.25 16.75 6.25C16.1977 6.25 15.75 6.69772 15.75 7.25C15.75 7.80228 16.1977 8.25 16.75 8.25ZM12 7.5C9.51472 7.5 7.5 9.51472 7.5 12C7.5 14.4853 9.51472 16.5 12 16.5C14.4853 16.5 16.5 14.4853 16.5 12C16.5027 10.8057 16.0294 9.65957 15.1849 8.81508C14.3404 7.97059 13.1943 7.49734 12 7.5ZM9.25 12C9.25 13.5188 10.4812 14.75 12 14.75C13.5188 14.75 14.75 13.5188 14.75 12C14.75 10.4812 13.5188 9.25 12 9.25C10.4812 9.25 9.25 10.4812 9.25 12Z" fill="CurrentColor"></path>
                        </svg></div>
                    </a>
                    <a href="#" class="footer4_social-link w-inline-block">
                      <div class="icon-embed-xsmall w-embed"><svg width="100%" height="100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M17.1761 4H19.9362L13.9061 10.7774L21 20H15.4456L11.0951 14.4066L6.11723 20H3.35544L9.80517 12.7508L3 4H8.69545L12.6279 9.11262L17.1761 4ZM16.2073 18.3754H17.7368L7.86441 5.53928H6.2232L16.2073 18.3754Z" fill="CurrentColor"></path>
                        </svg></div>
                    </a>
                    <a href="#" class="footer4_social-link w-inline-block">
                      <div class="icon-embed-xsmall w-embed"><svg width="100%" height="100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path fill-rule="evenodd" clip-rule="evenodd" d="M4.5 3C3.67157 3 3 3.67157 3 4.5V19.5C3 20.3284 3.67157 21 4.5 21H19.5C20.3284 21 21 20.3284 21 19.5V4.5C21 3.67157 20.3284 3 19.5 3H4.5ZM8.52076 7.00272C8.52639 7.95897 7.81061 8.54819 6.96123 8.54397C6.16107 8.53975 5.46357 7.90272 5.46779 7.00413C5.47201 6.15897 6.13998 5.47975 7.00764 5.49944C7.88795 5.51913 8.52639 6.1646 8.52076 7.00272ZM12.2797 9.76176H9.75971H9.7583V18.3216H12.4217V18.1219C12.4217 17.742 12.4214 17.362 12.4211 16.9819V16.9818V16.9816V16.9815V16.9812C12.4203 15.9674 12.4194 14.9532 12.4246 13.9397C12.426 13.6936 12.4372 13.4377 12.5005 13.2028C12.7381 12.3253 13.5271 11.7586 14.4074 11.8979C14.9727 11.9864 15.3467 12.3141 15.5042 12.8471C15.6013 13.1803 15.6449 13.5389 15.6491 13.8863C15.6605 14.9339 15.6589 15.9815 15.6573 17.0292V17.0294C15.6567 17.3992 15.6561 17.769 15.6561 18.1388V18.3202H18.328V18.1149C18.328 17.6629 18.3278 17.211 18.3275 16.7591V16.759V16.7588C18.327 15.6293 18.3264 14.5001 18.3294 13.3702C18.3308 12.8597 18.276 12.3563 18.1508 11.8627C17.9638 11.1286 17.5771 10.5211 16.9485 10.0824C16.5027 9.77019 16.0133 9.5691 15.4663 9.5466C15.404 9.54401 15.3412 9.54062 15.2781 9.53721L15.2781 9.53721L15.2781 9.53721C14.9984 9.52209 14.7141 9.50673 14.4467 9.56066C13.6817 9.71394 13.0096 10.0641 12.5019 10.6814C12.4429 10.7522 12.3852 10.8241 12.2991 10.9314L12.2991 10.9315L12.2797 10.9557V9.76176ZM5.68164 18.3244H8.33242V9.76733H5.68164V18.3244Z" fill="CurrentColor"></path>
                        </svg></div>
                    </a>
                    <a href="#" class="footer4_social-link w-inline-block">
                      <div class="icon-embed-xsmall w-embed"><svg width="100%" height="100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path fill-rule="evenodd" clip-rule="evenodd" d="M20.5686 4.77345C21.5163 5.02692 22.2555 5.76903 22.5118 6.71673C23.1821 9.42042 23.1385 14.5321 22.5259 17.278C22.2724 18.2257 21.5303 18.965 20.5826 19.2213C17.9071 19.8831 5.92356 19.8015 3.40294 19.2213C2.45524 18.9678 1.71595 18.2257 1.45966 17.278C0.827391 14.7011 0.871044 9.25144 1.44558 6.73081C1.69905 5.78311 2.44116 5.04382 3.38886 4.78753C6.96561 4.0412 19.2956 4.282 20.5686 4.77345ZM9.86682 8.70227L15.6122 11.9974L9.86682 15.2925V8.70227Z" fill="CurrentColor"></path>
                        </svg></div>
                    </a>
                    <a href="#" class="footer4_social-link w-inline-block">
                      <div class="icon-embed-xsmall w-embed"><svg width="100%" height="100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M22 12.0611C22 6.50451 17.5229 2 12 2C6.47715 2 2 6.50451 2 12.0611C2 17.0828 5.65684 21.2452 10.4375 22V14.9694H7.89844V12.0611H10.4375V9.84452C10.4375 7.32296 11.9305 5.93012 14.2146 5.93012C15.3088 5.93012 16.4531 6.12663 16.4531 6.12663V8.60261H15.1922C13.95 8.60261 13.5625 9.37822 13.5625 10.1739V12.0611H16.3359L15.8926 14.9694H13.5625V22C18.3432 21.2452 22 17.083 22 12.0611Z" fill="CurrentColor"></path>
                        </svg></div>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </main>
  </div>
  
  <script type="text/javascript">var $ = window.jQuery;</script><script src="<?php echo get_template_directory_uri(); ?>/assets/js/setima.js?v=1702910687" type="text/javascript"></script>
  <script type="text/javascript" src="https://player.vimeo.com/api/player.js"></script>
  <script>
  var player = new Vimeo.Player($("#vimeo-video")[0]);
  $("[vimeo=unmute]").click(function() {
    player.setCurrentTime(0);
    player.setMuted(false);
  });
  $("[vimeo=play]").click(function() {
    player.play();
  });
  $("[vimeo=pause]").click(function() {
    player.pause();
  });
</script>
  <!--  START: Mobile Autoplay Video  -->
  <script>
var mobilevideo = document.getElementsByTagName("video")[0];
mobilevideo.setAttribute("playsinline", "");
mobilevideo.setAttribute("muted", "");
</script>
  <!--  END: Mobile Autoplay Video  -->
  